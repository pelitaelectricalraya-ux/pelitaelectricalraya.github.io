Pelita Electrical Raya — GitHub Pages package

Put your logo per2025.png into assets/images/
Upload all files to a repo named USERNAME.github.io
