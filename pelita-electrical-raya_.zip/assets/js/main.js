// Pelita Electrical Raya frontend
console.log('Pelita Electrical Raya loaded');
